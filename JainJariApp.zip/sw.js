/* Jain Jari Gallery service worker.
   - keeps the app itself available offline (always tries the newest version first)
   - serves photos from this device, fetching them from the cloud the first time they are needed
   Photos and saved data are NEVER deleted by an app update. */
const SHELL="jj-shell-v3",IMG="jj-img",CFG="jj-cfg";
const CORE=["./","./index.html","./manifest.webmanifest","./icon-192.png","./icon-512.png","./lib/photoswipe.umd.min.js"];
let creds=null;
self.addEventListener("install",e=>{e.waitUntil(caches.open(SHELL).then(c=>c.addAll(CORE)).catch(()=>{}).then(()=>self.skipWaiting()))});
self.addEventListener("activate",e=>{e.waitUntil((async()=>{const ks=await caches.keys();await Promise.all(ks.filter(k=>k.startsWith("jj-shell-")&&k!==SHELL).map(k=>caches.delete(k)));await self.clients.claim()})())});
self.addEventListener("message",e=>{const d=e.data||{};if(d.type==="creds"){creds={u:d.u,k:d.k,t:d.t,uid:d.uid,du:d.du||"",dk:d.dk||""};
    e.waitUntil(caches.open(CFG).then(c=>c.put("creds",new Response(JSON.stringify(creds)))).catch(()=>{}))}});
async function getCreds(){if(creds)return creds;try{const c=await caches.open(CFG),r=await c.match("creds");if(r)creds=await r.json()}catch(e){}return creds}
async function askCreds(){try{(await self.clients.matchAll()).forEach(c=>c.postMessage({type:"needcreds"}))}catch(e){}}
function cloudPath(kind,name){const base=name.replace(/\.jpg$/,"");if(kind==="f")return "i/"+base+".jpg";if(kind==="t")return "i/"+base+".t.jpg";if(kind==="m")return "i/"+base+".m.jpg";if(kind==="b")return "b/"+base+".jpg";if(kind==="s")return "b/"+base+".t.jpg";return null}
async function serveImg(url){const key=url.origin+url.pathname,c=await caches.open(IMG);const hit=await c.match(key);if(hit)return hit;
  const m=url.pathname.match(/\/_img\/([ftmbs])\/([^/]+)$/);const p=m&&cloudPath(m[1],m[2]);const cr=await getCreds();
  if(!p||!cr)return new Response("",{status:404});
  const did=url.searchParams.get("d");
  if(did&&!cr.du)askCreds();
  if(did&&cr.du){try{const r=await fetch(cr.du+(cr.du.includes("?")?"&":"?")+"key="+encodeURIComponent(cr.dk)+"&op=get&id="+encodeURIComponent(did),{redirect:"follow"});const j=await r.json();
      if(j&&j.b64){const bin=atob(j.b64),arr=new Uint8Array(bin.length);for(let n=0;n<bin.length;n++)arr[n]=bin.charCodeAt(n);const b=new Blob([arr],{type:j.type||"image/jpeg"});
        const res=new Response(b,{headers:{"Content-Type":b.type,"Content-Length":String(b.size)}});c.put(key,res.clone()).catch(()=>{});return res}}catch(e){}}

  try{const r=await fetch(`${cr.u}/storage/v1/object/authenticated/photos/${cr.uid}/${p}`,{headers:{apikey:cr.k,Authorization:"Bearer "+cr.t}});
    if(r.ok){const b=await r.blob();const res=new Response(b,{headers:{"Content-Type":b.type||"image/jpeg","Content-Length":String(b.size)}});c.put(key,res.clone()).catch(()=>{});return res}
    if(r.status===400||r.status===401||r.status===403)askCreds();return new Response("",{status:404})}
  catch(e){return new Response("",{status:504})}}
self.addEventListener("fetch",e=>{const req=e.request;if(req.method!=="GET")return;const url=new URL(req.url);if(url.origin!==self.location.origin)return;
  if(url.pathname.includes("/_img/")){e.respondWith(serveImg(url));return}
  const isPage=req.mode==="navigate"||/\/(index\.html)?$/.test(url.pathname);
  if(isPage){e.respondWith((async()=>{const c=await caches.open(SHELL),hit=await c.match("./index.html");
      /* the saved copy opens at once; the newest copy is fetched in the background and used from the next opening */
      const net=fetch(req,{cache:"no-store"}).then(async r=>{if(r.ok&&r.type==="basic"){const old=await c.match("./index.html");const oldT=old?await old.text():"";const t=await r.clone().text();
          if(t!==oldT){await c.put("./index.html",new Response(t,{headers:{"Content-Type":"text/html; charset=utf-8"}}));if(old)(await self.clients.matchAll()).forEach(cl=>cl.postMessage({type:"update"}))}}return r});
      if(hit){e.waitUntil(net.catch(()=>{}));return hit}
      try{return await net}catch(err){return new Response("You are offline. Open the app once with internet first.",{status:503,headers:{"Content-Type":"text/plain"}})}})());return}
  /* app files (reader, scanner, icons): saved copy first, refreshed in the background */
  e.respondWith((async()=>{const c=await caches.open(SHELL),hit=await c.match(req,{ignoreSearch:true});
    const net=fetch(req).then(r=>{if(r.ok)c.put(req,r.clone()).catch(()=>{});return r});
    if(hit){net.catch(()=>{});return hit}try{return await net}catch(err){return new Response("",{status:504})}})())});
